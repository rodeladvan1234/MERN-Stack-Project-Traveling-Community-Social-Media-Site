

const Home = () => {
    return (
        <div>
            <h1>Cholona Ghure Ashi</h1>
        </div>
    );
};

export default Home;